from miniworlds.tools import inspection

class WorldInspection(inspection.Inspection):
    pass